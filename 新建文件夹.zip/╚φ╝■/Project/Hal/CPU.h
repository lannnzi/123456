#ifndef _CPU_H_
#define _CPU_H_

void hal_CPUInit(void);

void SysDelay1ms(unsigned int nTime);

#endif
