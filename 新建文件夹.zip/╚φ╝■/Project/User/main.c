
#include <stdio.h>
#include "OS_System.h"
#include "CPU.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_usart.h"
#include "hal_timer.h"
#include "oled.h"
#include "app.h"
#include "hal_Motor.h"
#include "RFID_RC522.h"


int main(void)
{

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);

    hal_CPUInit();
    OS_TaskInit();


    hal_timerInit();
    hal_UsartInit();
    hal_LedInit();

    RC522_Init();		 //RC522
    printf("��������!\r\n");

    hal_MotorInit();

    SysDelay1ms(4000);

    OS_Start();




}




